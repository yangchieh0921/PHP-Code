<!doctype html>
<html lang="en">

<head>
<meta charset="utf-8">
<title>Chieh Yang's Array </title>
</head>

<body>
<h1>List of months</h1>
<?php
$months = [
1 => 'Jan',
'Feb',
'Mar',
'Apr',
'May',
'Jun',
'Jul',
'Aug',
'Sep',
'Oct',
'Nov',
'Dec'
];
print "<p>$months</p>";
print r ($months);
?>
</body>
</html>

