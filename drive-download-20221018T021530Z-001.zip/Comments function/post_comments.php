<!doctype html>
<html lang="en">

<head>
<meta charset="utf-8">
<title>c_yang95632</title>
</head>

<body>
<?php
// This script receives data from commnets.html

// Get variables from the POST array
// Use the trim() function to get rid of spaces
$first_name = trim($_POST['first_name']);
$last_name = trim($_POST['last_name']);
$email = trim($_POST['email']);
$comments = trim($_POST['comments']);

// Create full name variable
$full_name = $first_name . ' ' . $last_name;

// Count the number of words entered in the comments section
$word_count = str_word_count($comments);

// Replace unwanted words using the str_ireplace() function
$comments = str_ireplace('suck', 'rocks', $comments);
$comments = str_ireplace('crap', 'awesome', $comments);

// Print out a message to the user
print "<div>Thank you $full_name, for the following comments:
<p>$comments</p>
<p>($word_count words total)</p></div>";
?>
</body>
</html>



