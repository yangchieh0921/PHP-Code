<!doctype html>
<html lang="en">
<head><title>View A Quotation</title></head>
<body>
<h1>Random Quotation </h1>
<?php // Read the file's contents into an array 
$data = file('./quotes.txt');
// Count the number of items in the array 
$n = count($data);
// Pick a random quote
$rand = rand(0, ($n - 1));
// Print the quote
print '<p>' . trim($data[$rand]) . '</p>';
?>
</body>
</html>